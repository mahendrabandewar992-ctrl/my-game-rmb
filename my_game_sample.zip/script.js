let canvas = document.getElementById("gameCanvas");
let ctx = canvas.getContext("2d");

canvas.width = 400;
canvas.height = 400;

// Background
ctx.fillStyle = "green";
ctx.fillRect(0, 0, canvas.width, canvas.height);

// Text
ctx.fillStyle = "yellow";
ctx.font = "30px Arial";
ctx.fillText("Game Ready!", 100, 200);
